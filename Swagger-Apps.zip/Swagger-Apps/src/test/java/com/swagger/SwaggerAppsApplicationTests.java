package com.swagger;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SwaggerAppsApplicationTests {

	@Test
	void contextLoads() {
	}

}
