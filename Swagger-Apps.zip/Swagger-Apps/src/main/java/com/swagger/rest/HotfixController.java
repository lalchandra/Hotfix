package com.swagger.rest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.swagger.request.HotfixInfo;
import com.swagger.response.DeatilsInfo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@Api("This is Details of an Employe which has been fixed")
public class HotfixController {
	
	  @ApiOperation("This is used to enter the details")
	  @PostMapping("/enterDetails")
      public ResponseEntity<HotfixInfo> enterDetails(@RequestBody DeatilsInfo dinfo)
      {
    	  HotfixInfo hotfix = new HotfixInfo();
    	  hotfix.setCRTitle(dinfo.getCRTitle());
    	  hotfix.setCRType(dinfo.getCRType());
    	  hotfix.setCRNumber(dinfo.getCRNumber());
    	  hotfix.setCaseNumber(dinfo.getCaseNumber());
    	  hotfix.setReleaseDate(dinfo.getReleaseDate());
    	  hotfix.setReleaseBy(dinfo.getReleaseBy());
    	  hotfix.setReportingRelease(dinfo.getReportingRelease());
    	  hotfix.setRolledUpToRelease(dinfo.getRolledUpToRelease());
    	  hotfix.setOriginalCr(dinfo.getOriginalCr());
    	  hotfix.setGerritIds(dinfo.getGerritIds());
    	  hotfix.setComment(dinfo.getComment());
    	  hotfix.setEntryStatus("Success");
    	  
    	  return new ResponseEntity<>(hotfix,HttpStatus.CREATED);
    	  
    	  
      }
	  
}