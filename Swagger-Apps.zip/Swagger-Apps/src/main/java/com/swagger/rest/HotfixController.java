package com.swagger.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.swagger.entities.Details;
import com.swagger.request.HotfixInfo;
import com.swagger.response.DeatilsInfo;
import com.swagger.services.DetailsService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@Api("This is Details of an Employe which has been fixed")
public class HotfixController {
	
	  @ApiOperation("This is used to enter the details")
	  @PostMapping("/enterDetails")
      public ResponseEntity<HotfixInfo> enterDetails(@RequestBody DeatilsInfo dinfo)
      {
    	  HotfixInfo hotfix = new HotfixInfo();
    	  hotfix.setCRTitle(dinfo.getCRTitle());
    	  hotfix.setCRType(dinfo.getCRType());
    	  hotfix.setCRNumber(dinfo.getCRNumber());
    	  hotfix.setCaseNumber(dinfo.getCaseNumber());
    	  hotfix.setReleaseDate(dinfo.getReleaseDate());
    	  hotfix.setReleaseBy(dinfo.getReleaseBy());
    	  hotfix.setReportingRelease(dinfo.getReportingRelease());
    	  hotfix.setRolledUpToRelease(dinfo.getRolledUpToRelease());
    	  hotfix.setOriginalCr(dinfo.getOriginalCr());
    	  hotfix.setGerritIds(dinfo.getGerritIds());
    	  hotfix.setComment(dinfo.getComment());
    	  hotfix.setEntryStatus("Success");
    	  
    	  return new ResponseEntity<>(hotfix,HttpStatus.CREATED);
    	  
      }
	  
	  @Autowired
	  private DetailsService detailservice;
	  @ApiOperation("This is used to enter the details")
	  @GetMapping("/getDetails")
	  public List<Details> getDetails()
	  {
		  return this.detailservice.getDetails();
		  
		  
	  }
	  
	  @GetMapping("/getDetails/{CRNumbr}")
	  public List<Details> getData(String CRNumber)
	  {
		  return this.detailservice.getDetail(CRNumber);
	  }
	  
	  @PutMapping("/updateDetails")
	  public Details updateDetails(@RequestBody Details dinfo)
	  {
		  return this.detailservice.updateDetails(dinfo);
	  }
	  
	  @DeleteMapping("deleteDetails/{CRNumber}")
	  public ResponseEntity<HttpStatus> deleteDetails(@PathVariable String CRNumber)
	  {
		  try {
			  this.detailservice.deleteDetails(CRNumber);
			  return new ResponseEntity<>(HttpStatus.OK);
		  } catch(Exception e)
		  {
			  return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		  }
		  
	  }
}