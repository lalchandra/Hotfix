package com.swagger.services;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.swagger.entities.Details;
@Service
public class DetailsServiceImpl implements DetailsService {

	List<Details> list,list1;
	
	public DetailsServiceImpl()
	{
		list=new ArrayList<>();
		list.add(new Details("Debug prblm","Rolldown","10001","20001","20.01.01.00","SDC","12-02-2021","L3 team","NA","NA","NA","https://nedje/snd","review by me"));
		list.add(new Details("Testing prblm","Rollup","10002","20002","20.01.01.01","SADC","12-03-2021","L4 team","NA","NA","NA","https://nedjedfr/sndf","review by team lead"));
		
	}
	
	@Override
	public List<Details> getDetails() {
		// TODO Auto-generated method stub
		return list;
	}
	
	@Override
	public List<Details> getDetail(String CRNumber) {
		// TODO Auto-generated method stub
		list1=new ArrayList<>();
		//Details d=null;
		list.forEach(e-> {;
		      if(e.getCRNumber()==CRNumber)
		      {
		    	 list1.add(new Details(e.getCRTitle(),e.getCRType(),e.getCRNumber(),e.getCaseNumber(),e.getReleaseTag(),e.getAfftectedProduct(),
		    			 e.getReleaseDate(),e.getReleaseBy(),e.getReportingRelease(),e.getRolledUpToRelease(),e.getOriginalCr(),e.getGerritIds(),
		    			 e.getComment())); 
		      }
		});
		return list1;
	}

	@Override
	public Details updateDetails(Details dinfo) {
		// TODO Auto-generated method stub
		list.forEach(hotfix->{
			if(hotfix.getCRNumber()==dinfo.getCRNumber())
			{
				hotfix.setCRTitle(dinfo.getCRTitle());
		    	  hotfix.setCRType(dinfo.getCRType());
		    	  hotfix.setCRNumber(dinfo.getCRNumber());
		    	  hotfix.setCaseNumber(dinfo.getCaseNumber());
		    	  hotfix.setReleaseDate(dinfo.getReleaseDate());
		    	  hotfix.setReleaseBy(dinfo.getReleaseBy());
		    	  hotfix.setReportingRelease(dinfo.getReportingRelease());
		    	  hotfix.setRolledUpToRelease(dinfo.getRolledUpToRelease());
		    	  hotfix.setOriginalCr(dinfo.getOriginalCr());
		    	  hotfix.setGerritIds(dinfo.getGerritIds());
		    	  hotfix.setComment(dinfo.getComment());
		    	  hotfix.setEntryStatus("Success");	
			}
		});
		return dinfo;
	}

	@Override
	public void deleteDetails(String CRNumber) {
		// TODO Auto-generated method stub
		list=this.list.stream().filter(e->e.getCRNumber()!=CRNumber).collect(Collectors.toList());
		
	}
	

}
