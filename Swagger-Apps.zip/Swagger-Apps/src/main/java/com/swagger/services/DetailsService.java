package com.swagger.services;

import java.util.List;

import com.swagger.entities.Details;

public interface DetailsService {
        
	public List<Details> getDetails(); 
	public List<Details> getDetail(String CRNumber);
	public Details updateDetails(Details dinfo);
	public void deleteDetails(String CRNumber);
}
