package com.swagger.entities;

public class Details {
    
	private String CRTitle;
	private String CRType;
	private String CRNumber;
	private String CaseNumber;
	private String ReleaseTag;
	private String AfftectedProduct;
	private String ReleaseDate;
	private String ReleaseBy;
	private String ReportingRelease;
	private String RolledUpToRelease;
	private String OriginalCr;
	private String GerritIds;
	private String Comment;
	private String EntryStatus;
	
	public String getEntryStatus() {
		return EntryStatus;
	}

	public void setEntryStatus(String entryStatus) {
		EntryStatus = entryStatus;
	}

	@Override
	public String toString() {
		return "Details [CRTitle=" + CRTitle + ", CRType=" + CRType + ", CRNumber=" + CRNumber + ", CaseNumber="
				+ CaseNumber + ", ReleaseTag=" + ReleaseTag + ", AfftectedProduct=" + AfftectedProduct
				+ ", ReleaseDate=" + ReleaseDate + ", ReleaseBy=" + ReleaseBy + ", ReportingRelease=" + ReportingRelease
				+ ", RolledUpToRelease=" + RolledUpToRelease + ", OriginalCr=" + OriginalCr + ", GerritIds=" + GerritIds
				+ ", Comment=" + Comment + "]";
	}

	public String getCRTitle() {
		return CRTitle;
	}

	public void setCRTitle(String cRTitle) {
		CRTitle = cRTitle;
	}

	public String getCRType() {
		return CRType;
	}

	public void setCRType(String cRType) {
		CRType = cRType;
	}

	public String getCRNumber() {
		return CRNumber;
	}

	public void setCRNumber(String cRNumber) {
		CRNumber = cRNumber;
	}

	public String getCaseNumber() {
		return CaseNumber;
	}

	public void setCaseNumber(String caseNumber) {
		CaseNumber = caseNumber;
	}

	public String getReleaseTag() {
		return ReleaseTag;
	}

	public void setReleaseTag(String releaseTag) {
		ReleaseTag = releaseTag;
	}

	public String getAfftectedProduct() {
		return AfftectedProduct;
	}

	public void setAfftectedProduct(String afftectedProduct) {
		AfftectedProduct = afftectedProduct;
	}

	public String getReleaseDate() {
		return ReleaseDate;
	}

	public void setReleaseDate(String releaseDate) {
		ReleaseDate = releaseDate;
	}

	public String getReleaseBy() {
		return ReleaseBy;
	}

	public void setReleaseBy(String releaseBy) {
		ReleaseBy = releaseBy;
	}

	public String getReportingRelease() {
		return ReportingRelease;
	}

	public void setReportingRelease(String reportingRelease) {
		ReportingRelease = reportingRelease;
	}

	public String getRolledUpToRelease() {
		return RolledUpToRelease;
	}

	public void setRolledUpToRelease(String rolledUpToRelease) {
		RolledUpToRelease = rolledUpToRelease;
	}

	public String getOriginalCr() {
		return OriginalCr;
	}

	public void setOriginalCr(String originalCr) {
		OriginalCr = originalCr;
	}

	public String getGerritIds() {
		return GerritIds;
	}

	public void setGerritIds(String gerritIds) {
		GerritIds = gerritIds;
	}

	public String getComment() {
		return Comment;
	}

	public void setComment(String comment) {
		Comment = comment;
	}

	public Details(String string, String string2, String string3, String string4, String string5, String string6, String string7, String string8, String string9, String string10) {
		super();
		// TODO Auto-generated constructor stub
	}

	public Details(String cRTitle, String cRType, String cRNumber, String caseNumber, String releaseTag,
			String afftectedProduct, String releaseDate, String releaseBy, String reportingRelease,
			String rolledUpToRelease, String originalCr, String gerritIds, String comment) {
		super();
		CRTitle = cRTitle;
		CRType = cRType;
		CRNumber = cRNumber;
		CaseNumber = caseNumber;
		ReleaseTag = releaseTag;
		AfftectedProduct = afftectedProduct;
		ReleaseDate = releaseDate;
		ReleaseBy = releaseBy;
		ReportingRelease = reportingRelease;
		RolledUpToRelease = rolledUpToRelease;
		OriginalCr = originalCr;
		GerritIds = gerritIds;
		Comment = comment;
	}

}
