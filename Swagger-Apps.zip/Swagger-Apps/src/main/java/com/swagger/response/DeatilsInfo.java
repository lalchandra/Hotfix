package com.swagger.response;

import lombok.Data;

@Data
public class DeatilsInfo {
      
	private String CRTitle;
	private String CRType;
	private String CRNumber;
	private String CaseNumber;
	private String ReleaseTag;
	private String AfftectedProduct;
	private String ReleaseDate;
	private String ReleaseBy;
	private String ReportingRelease;
	private String RolledUpToRelease;
	private String OriginalCr;
	private String GerritIds;
	private String Comment;
	
	
	public String getCRTitle() {
		return CRTitle;
	}
	public void setCRTitle(String cRTitle) {
		CRTitle = cRTitle;
	}
	public String getCRType() {
		return CRType;
	}
	public void setCRType(String cRType) {
		CRType = cRType;
	}
	public String getCRNumber() {
		return CRNumber;
	}
	public void setCRNumber(String cRNumber) {
		CRNumber = cRNumber;
	}
	public String getCaseNumber() {
		return CaseNumber;
	}
	public void setCaseNumber(String caseNumber) {
		CaseNumber = caseNumber;
	}
	public String getReleaseTag() {
		return ReleaseTag;
	}
	public void setReleaseTag(String releaseTag) {
		ReleaseTag = releaseTag;
	}
	public String getAfftectedProduct() {
		return AfftectedProduct;
	}
	public void setAfftectedProduct(String afftectedProduct) {
		AfftectedProduct = afftectedProduct;
	}
	public String getReleaseDate() {
		return ReleaseDate;
	}
	public void setReleaseDate(String releaseDate) {
		ReleaseDate = releaseDate;
	}
	public String getReleaseBy() {
		return ReleaseBy;
	}
	public void setReleaseBy(String releaseBy) {
		ReleaseBy = releaseBy;
	}
	public String getReportingRelease() {
		return ReportingRelease;
	}
	public void setReportingRelease(String reportingRelease) {
		ReportingRelease = reportingRelease;
	}
	public String getRolledUpToRelease() {
		return RolledUpToRelease;
	}
	public void setRolledUpToRelease(String rolledUpToRelease) {
		RolledUpToRelease = rolledUpToRelease;
	}
	public String getOriginalCr() {
		return OriginalCr;
	}
	public void setOriginalCr(String originalCr) {
		OriginalCr = originalCr;
	}
	public String getGerritIds() {
		return GerritIds;
	}
	public void setGerritIds(String gerritIds) {
		GerritIds = gerritIds;
	}
	public String getComment() {
		return Comment;
	}
	public void setComment(String comment) {
		Comment = comment;
	}
	
	
}
