package com.amdocs.hflogtool.api;

import com.amdocs.hflogtool.model.CREntity;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CRRepository extends CrudRepository<CREntity,String> {
}
