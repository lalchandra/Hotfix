package com.amdocs.hflogtool.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.ArrayList;

@Entity
@Table(name = "CR")
@Getter @Setter
public class CREntity {
    @Id
    private String id;
    private String title;
    private String productName;
    private String releaseTag;
    private String owner;
    private String type;
    private String reportingRelease;
    private String rolledUpToRelease;
    private String rolledDownFromRelease;
    private String gerritId;
    private String comments;
}


