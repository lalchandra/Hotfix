package com.amdocs.hflogtool.services.core;

import com.amdocs.hflogtool.api.CRRepository;
import com.amdocs.hflogtool.model.CREntity;
import com.amdocs.hflogtool.services.api.CRService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CRServiceImpl implements CRService {

    private final CRRepository crRepository;

    @Autowired
    public CRServiceImpl(CRRepository crRepository) {
        this.crRepository = crRepository;
    }

    @Override
    public void save(CREntity crEntity) {
        crRepository.save(crEntity);
    }

    @Override
    public List<CREntity> findAll() {
        return null;
    }

    @Override
    public CREntity findById(String id) {
        return crRepository.findById(id).orElse(null);
    }
}
