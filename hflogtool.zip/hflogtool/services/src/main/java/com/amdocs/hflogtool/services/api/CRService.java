package com.amdocs.hflogtool.services.api;

import com.amdocs.hflogtool.model.CREntity;

import java.util.List;

public interface CRService {
    void save(CREntity cr);

    List<CREntity> findAll();

    CREntity findById(String id);
}
