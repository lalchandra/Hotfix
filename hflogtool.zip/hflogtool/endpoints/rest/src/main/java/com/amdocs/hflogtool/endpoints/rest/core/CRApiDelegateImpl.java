package com.amdocs.hflogtool.endpoints.rest.core;

import com.amdocs.hflogtool.api.CRApiDelegate;
import com.amdocs.hflogtool.model.CR;
import com.amdocs.hflogtool.services.api.CRService;
import com.amdocs.hflogtool.endpoints.rest.core.mapper.CRMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CRApiDelegateImpl implements CRApiDelegate {

    private final CRService crService;

    @Autowired
    public CRApiDelegateImpl(CRService crService) {
        this.crService = crService;
    }

    @Override
    public ResponseEntity<Void> addCR(CR cr) {
        crService.save(CRMapper.INSTANCE.mapCRToCREntity(cr));
        return null;
    }

    @Override
    public ResponseEntity<List<CR>> findAllCR() {
        crService.findAll();
        return null;
    }

    @Override
    public ResponseEntity<CR> findCRByID(String id) {
        return new ResponseEntity<>(CRMapper.INSTANCE.mapCREntityToCR(crService.findById(id)),HttpStatus.ACCEPTED);
    }
}
