package com.hotfix;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotFixLogToolApplication {

	public static void main(String[] args) {
		SpringApplication.run(HotFixLogToolApplication.class, args);
	}

}
