package com.hotfix.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.hotfix.entities.Detail;
import com.hotfix.services.DetailService;


import io.swagger.annotations.Api;


@RestController
@Api("This is Details of an Employe which has been fixed")
public class HotfixController {
	
	@Autowired
	private DetailService detailservice;
	@GetMapping("/home")
	public String home()
	{
		return "Welcome to the HotFix Log Tool";
	}
     
	@GetMapping("/getDetails")
   public List<Detail> getDetails()
   {
	   return this.detailservice.getDetails();
   }
	
	@GetMapping("/getDetail/{CRNumber}")
   public Detail  getDetail(@PathVariable String CRNumber)
   { 
	   return this.detailservice.getDetail(Long.parseLong(CRNumber));
   }
	
	
	
  @PostMapping("/putDetails")
  public Detail addDetails(@RequestBody Detail detail)
  {
	  return this.detailservice.addDetails(detail);
  }
  
  
  @DeleteMapping("deleteDetails/{CRNumber}")
  public ResponseEntity<HttpStatus> deleteDetails(@PathVariable String CRNumber)
  {
	  try {
		  this.detailservice.deleteDetails(Long.parseLong(CRNumber));
		  return new ResponseEntity<>(HttpStatus.OK);
	  } catch(Exception e)
	  {
		  return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	  }
	  
  }
  
  @PutMapping("/updateDetails")
  public Detail updateDetails(@RequestBody Detail dinfo)
  {
	  return this.detailservice.updateDetails(dinfo);
  }
	
}
