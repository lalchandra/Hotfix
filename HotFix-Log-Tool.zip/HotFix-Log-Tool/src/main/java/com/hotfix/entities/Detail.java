package com.hotfix.entities;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Detail {
   
	@Id
	private int CRNumber;
	private String CRTitle;
	private String CRType;
	private String CaseNumber;
	private String ReleaseTag;
	private String AfftectedProduct;
	private String ReleaseDate;
	private String ReleaseBy;
	private String ReportingRelease;
	private String RolledUpToRelease;
	private String OriginalCr;
	private String GerritIds;
	private String Comment;
	
	@Override
	public String toString() {
		return "Detail [CRNumber=" + CRNumber + ", CRTitle=" + CRTitle + ", CRType=" + CRType + ", CaseNumber="
				+ CaseNumber + ", ReleaseTag=" + ReleaseTag + ", AfftectedProduct=" + AfftectedProduct
				+ ", ReleaseDate=" + ReleaseDate + ", ReleaseBy=" + ReleaseBy + ", ReportingRelease=" + ReportingRelease
				+ ", RolledUpToRelease=" + RolledUpToRelease + ", OriginalCr=" + OriginalCr + ", GerritIds=" + GerritIds
				+ ", Comment=" + Comment + "]";
	}
	public Detail() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Detail(int i, String cRTitle, String cRType, String caseNumber, String releaseTag,
			String afftectedProduct, String releaseDate, String releaseBy, String reportingRelease,
			String rolledUpToRelease, String originalCr, String gerritIds, String comment) {
		super();
		CRNumber = i;
		CRTitle = cRTitle;
		CRType = cRType;
		CaseNumber = caseNumber;
		ReleaseTag = releaseTag;
		AfftectedProduct = afftectedProduct;
		ReleaseDate = releaseDate;
		ReleaseBy = releaseBy;
		ReportingRelease = reportingRelease;
		RolledUpToRelease = rolledUpToRelease;
		OriginalCr = originalCr;
		GerritIds = gerritIds;
		Comment = comment;
	}
	public int getCRNumber() {
		return CRNumber;
	}
	public void setCRNumber(int cRNumber) {
		CRNumber = cRNumber;
	}
	public String getCRTitle() {
		return CRTitle;
	}
	public void setCRTitle(String cRTitle) {
		CRTitle = cRTitle;
	}
	public String getCRType() {
		return CRType;
	}
	public void setCRType(String cRType) {
		CRType = cRType;
	}
	public String getCaseNumber() {
		return CaseNumber;
	}
	public void setCaseNumber(String caseNumber) {
		CaseNumber = caseNumber;
	}
	public String getReleaseTag() {
		return ReleaseTag;
	}
	public void setReleaseTag(String releaseTag) {
		ReleaseTag = releaseTag;
	}
	public String getAfftectedProduct() {
		return AfftectedProduct;
	}
	public void setAfftectedProduct(String afftectedProduct) {
		AfftectedProduct = afftectedProduct;
	}
	public String getReleaseDate() {
		return ReleaseDate;
	}
	public void setReleaseDate(String releaseDate) {
		ReleaseDate = releaseDate;
	}
	public String getReleaseBy() {
		return ReleaseBy;
	}
	public void setReleaseBy(String releaseBy) {
		ReleaseBy = releaseBy;
	}
	public String getReportingRelease() {
		return ReportingRelease;
	}
	public void setReportingRelease(String reportingRelease) {
		ReportingRelease = reportingRelease;
	}
	public String getRolledUpToRelease() {
		return RolledUpToRelease;
	}
	public void setRolledUpToRelease(String rolledUpToRelease) {
		RolledUpToRelease = rolledUpToRelease;
	}
	public String getOriginalCr() {
		return OriginalCr;
	}
	public void setOriginalCr(String originalCr) {
		OriginalCr = originalCr;
	}
	public String getGerritIds() {
		return GerritIds;
	}
	public void setGerritIds(String gerritIds) {
		GerritIds = gerritIds;
	}
	public String getComment() {
		return Comment;
	}
	public void setComment(String comment) {
		Comment = comment;
	}

}
