package com.hotfix.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hotfix.entities.Detail;

@Repository
public interface DetailsDao extends JpaRepository<Detail, Long> {
   
}
