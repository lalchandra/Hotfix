package com.hotfix.services;

import java.util.*;

import com.hotfix.entities.Detail;

public interface DetailService {
    
	public List<Detail> getDetails();
	public Detail getDetail(long CRNumber);
	public Detail addDetails(Detail detail);
	public void deleteDetails(long CRNumber);
	public Detail updateDetails(Detail dinfo);
	
}
