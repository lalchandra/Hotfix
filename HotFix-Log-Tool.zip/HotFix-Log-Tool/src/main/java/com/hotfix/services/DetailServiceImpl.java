package com.hotfix.services;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hotfix.dao.DetailsDao;
import com.hotfix.entities.Detail;

@Service
public class DetailServiceImpl implements DetailService{
	
    //List<Detail> list,list1;
	@Autowired
	private DetailsDao detailsdao;
	
	public DetailServiceImpl()
	{
		//list=new ArrayList<>();
		//list.add(new Detail(1001,"Debug prblm","Rolldown","20001","20.01.01.00","SDC","12-02-2021","L3 team","NA","NA","NA","https://nedje/snd","review by me"));
		//list.add(new Detail(1002,"Testing prblm","Rollup","20002","20.01.01.01","SADC","12-03-2021","L4 team","NA","NA","NA","https://nedjedfr/sndf","review by team lead"));
		
	}

	@Override
	public List<Detail> getDetails() {
		// TODO Auto-generated method stub
		return detailsdao.findAll();
	}

	@Override
	public Detail getDetail(long CRNumber) {
		// TODO Auto-generated method stub
		/*Detail d=null;
		for(Detail de:list)
		{
			if(de.getCRNumber()==CRNumber)
			{
				d=de;
				break;
			}
		}*/
		return detailsdao.getOne(CRNumber);
	}

	@Override
	public Detail addDetails(Detail detail) {
		// TODO Auto-generated method stub
	//	list.add(detail);
		detailsdao.save(detail);
		return detail;
	}

	@Override
	public void deleteDetails(long CRNumber) {
		// TODO Auto-generated method stub
		//list=this.list.stream().filter(e->e.getCRNumber()!=CRNumber).collect(Collectors.toList());
		Detail entity = detailsdao.getOne(CRNumber);
		detailsdao.delete(entity);
	}
	

	@Override
	public Detail updateDetails(Detail dinfo) {
		// TODO Auto-generated method stub
	/*	list.forEach(hotfix->{
			if(hotfix.getCRNumber()==dinfo.getCRNumber())
			{
				hotfix.setCRNumber(dinfo.getCRNumber());
				hotfix.setCRTitle(dinfo.getCRTitle());
		    	  hotfix.setCRType(dinfo.getCRType());
		    	  hotfix.setCaseNumber(dinfo.getCaseNumber());
		    	  hotfix.setReleaseDate(dinfo.getReleaseDate());
		    	  hotfix.setReleaseBy(dinfo.getReleaseBy());
		    	  hotfix.setReportingRelease(dinfo.getReportingRelease());
		    	  hotfix.setRolledUpToRelease(dinfo.getRolledUpToRelease());
		    	  hotfix.setOriginalCr(dinfo.getOriginalCr());
		    	  hotfix.setGerritIds(dinfo.getGerritIds());
		    	  hotfix.setComment(dinfo.getComment());
		    	  //hotfix.setEntryStatus("Success");	
			}
		}); */
		
		
		detailsdao.save(dinfo);
		return dinfo;
		
	}

}
