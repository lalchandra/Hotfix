package com.hotfix;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotFixLogToolApplicationTests {

	@Test
	void contextLoads() {
	}

}
